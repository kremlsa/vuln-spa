import React, { useState, useEffect } from 'react';

function App() {
  const [authenticated, setAuthenticated] = useState(false);
  const [notes, setNotes] = useState([]);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');

  useEffect(() => {
    if (authenticated) {
      fetchNotes();
    }
  }, [authenticated]);

  const fetchNotes = () => {
    fetch('/api/notes', { credentials: 'include' })
      .then(response => {
        if (!response.ok) throw new Error('Error fetching notes');
        return response.json();
      })
      .then(data => setNotes(data))
      .catch(error => {
        console.error('Ошибка загрузки заметок:', error);
        alert('Ошибка при загрузке заметок.');
      });
  };

  const handleLogin = (e) => {
    e.preventDefault();

    const formData = new URLSearchParams();
    formData.append('username', username);
    formData.append('password', password);

    fetch('/login', {
      method: 'POST',
      body: formData,
      credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    })
    .then(response => {
      if (response.ok) {
        setAuthenticated(true);
      } else {
        alert('Ошибка входа. Неверный логин или пароль.');
      }
    })
    .catch(error => {
      console.error('Ошибка при попытке входа:', error);
      alert('Ошибка при попытке входа.');
    });
  };

  const handleCreateNote = (e) => {
    e.preventDefault();

    const noteData = { title: newTitle, content: newContent };

    fetch('/api/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(noteData)
    })
    .then(response => {
      if (response.ok) {
        fetchNotes();
        setNewTitle('');
        setNewContent('');
      } else {
        alert('Ошибка создания заметки.');
      }
    })
    .catch(error => {
      console.error('Ошибка при создании заметки:', error);
      alert('Ошибка при создании заметки.');
    });
  };

  const handleDeleteNote = (id) => {
    if (!window.confirm('Удалить заметку?')) return;

    fetch(`/api/notes/${id}`, {
      method: 'DELETE',
      credentials: 'include'
    })
    .then(response => {
      if (response.ok) {
        fetchNotes();
      } else {
        alert('Ошибка удаления заметки.');
      }
    })
    .catch(error => {
      console.error('Ошибка при удалении заметки:', error);
      alert('Ошибка при удалении заметки.');
    });
  };

  if (!authenticated) {
    return (
      <div>
        <h1>Login</h1>
        <form onSubmit={handleLogin}>
          <div>
            <label>Username: </label>
            <input value={username} onChange={e => setUsername(e.target.value)} />
          </div>
          <div>
            <label>Password: </label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} />
          </div>
          <button type="submit">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div>
      <h1>Notes (Уязвимая версия)</h1>

      <form onSubmit={handleCreateNote}>
        <div>
          <input
            placeholder="Title"
            value={newTitle}
            onChange={e => setNewTitle(e.target.value)}
          />
        </div>
        <div>
          <textarea
            placeholder="Content"
            value={newContent}
            onChange={e => setNewContent(e.target.value)}
          />
        </div>
        <button type="submit">Создать заметку</button>
      </form>

      <hr />

      {notes.map(note => (
        <div key={note.id} style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ccc' }}>
          <h2>{note.title}</h2>
          <p dangerouslySetInnerHTML={{ __html: note.content }} />
          <button onClick={() => handleDeleteNote(note.id)}>Удалить</button>
        </div>
      ))}
    </div>
  );
}

export default App;
